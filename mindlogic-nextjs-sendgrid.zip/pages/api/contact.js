
export default async function handler(req, res) {
  if (req.method === 'POST') {
    const { name, email, message } = req.body;

    // TODO: Add SendGrid API integration here
    console.log("Contact form submitted:", name, email, message);

    res.status(200).json({ success: true, message: "Message received." });
  } else {
    res.status(405).json({ message: "Method not allowed" });
  }
}
