
export default function Home() {
  return (
    <div style={{fontFamily: 'Arial', textAlign: 'center', padding: '50px'}}>
      <h1>Welcome to MindLogic</h1>
      <p>AI Tech Consulting • Emotional Physiology • Education</p>
    </div>
  )
}
